package Variables;

public class UserData {
    public static final String USER_NAME = "Test";
    public static final String USER_EMAIL = "qaands@gmail.com";
    public static final String USER_PHONE = "+375445889764";
    public static final String DESCRIPTION = "There is test";

}
