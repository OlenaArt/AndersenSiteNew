package Steps;

import Variables.UserData;
import io.cucumber.java.en.And;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static Steps.Hooks.driver;

public class GeneralCTASteps {

    @And("User click on the Request consultation button")
    public void userClickOnTheRequestConsultationButton() throws InterruptedException  {
        WebElement CTAButton = driver.findElement(By.xpath("//*[@id=\"architect\"]/div/div[2]/button"));
        TimeUnit.SECONDS.sleep(2);
        CTAButton.click();
    }

    @And("User select Industry in the CTA form")
    public void userSelectIndustryInTheCTAForm() {
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cta-block\"]/div[1]/div/div/div[1]/button")));
        WebElement SelectIndustry = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[1]/div/div/div[1]/button"));
        SelectIndustry.click();
        WebElement Other = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[1]/div/div/div[1]/div[2]/div[5]"));
        Other.click();
    }

    @And("User fills Name field in the CTA form")
    public void userFillsNameFieldInTheCTAForm() {
        WebElement UserName = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[2]/div[1]/div/label/input"));
        UserName.sendKeys(UserData.USER_NAME);
    }

    @And("User fills Email field in the CTA form")
    public void userFillsEmailFieldInTheCTAForm() {
        WebElement Email = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[2]/div[2]/div/label/input"));
        Email.sendKeys(UserData.USER_EMAIL);
    }

    @And("User fills Phone field in the CTA form")
    public void userFillsPhoneFieldInTheCTAForm() {
        WebElement Phone = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[3]/div/div[1]/label/input"));
        Phone.sendKeys(UserData.USER_PHONE);
    }

    @And("User fills Comments field in the CTA form")
    public void userFillsCommentsFieldInTheCTAForm() {
        WebElement Description = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[3]/div/div[2]/label/textarea"));
        Description.sendKeys(UserData.DESCRIPTION);
    }

    @And("User click on the checkbox in the CTA form")
    public void userClickOnTheCheckboxInTheCTAForm() {
        WebElement CheckBox = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[4]/div/div[2]"));
        CheckBox.click();
    }

    @And("User Click on the Send button in the CTA form")
    public void userClickOnTheSendButtonInTheCTAForm() throws InterruptedException {
        WebElement Send = driver.findElement(By.xpath("//*[@id=\"cta-block\"]/div[4]/div/div[1]/button"));
        Send.click();
        TimeUnit.SECONDS.sleep(2);

    }
}
