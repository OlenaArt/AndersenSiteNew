package Steps;

import Steps.Hooks;
import Variables.UserData;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static Steps.Hooks.driver;

public class GeneralCVSteps {

    @And("User click on the Request CV's button")
    public void userClickOnTheRequestCVSButton() throws InterruptedException {
        WebElement CVButton = driver.findElement(By.xpath("//*[@id=\"experts\"]/div/aside/div[2]/button"));
        TimeUnit.SECONDS.sleep(2);
        CVButton.click();
    }

    @And("User select Industry in the CV form")
    public void userSelectIndustryInTheCVForm() {
        new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"cv-slider\"]/div[1]/div/div/div[1]/button")));
        WebElement SelectIndustry = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[1]/div/div/div[1]/button"));
        SelectIndustry.click();
        WebElement FinServ = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[1]/div/div/div[1]/div[2]/div[2]"));
        FinServ.click();
    }

    @And("User fills Name field in the CV form")
    public void userFillsNameFieldInTheCVForm() {
        WebElement UserName = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[2]/div[1]/div/label/input"));
        UserName.sendKeys(UserData.USER_NAME);

    }

    @And("User fills Email field in the CV form")
    public void userFillsEmailFieldInTheCVForm() {
        WebElement Email = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[2]/div[2]/div/label/input"));
        Email.sendKeys(UserData.USER_EMAIL);

    }

    @And("User fills Phone field in the Cv form")
    public void userFillsPhoneFieldInTheCvForm() {
        WebElement Phone = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[3]/div/div[1]/label/input"));
        Phone.sendKeys(UserData.USER_PHONE);
    }

    @And("User fills Comments field in the CV form")
    public void userFillsCommentsFieldInTheCVForm() {
        WebElement Description = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[3]/div/div[2]/label/textarea"));
        Description.sendKeys(UserData.DESCRIPTION);
    }

    @And("User click on the checkbox in the CV form")
    public void userClickOnTheCheckboxInTheCVForm() {
        WebElement CheckBox = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[4]/div/div[2]"));
        CheckBox.click();
    }

    @And("User Click on the Send button in the CV form")
    public void userClickOnTheSendButtonInTheCVForm() throws InterruptedException {
        WebElement Send = driver.findElement(By.xpath("//*[@id=\"cv-slider\"]/div[4]/div/div[1]/button"));
        Send.click();
        TimeUnit.SECONDS.sleep(2);
    }
}
